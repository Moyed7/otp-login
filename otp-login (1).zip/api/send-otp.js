
import sgMail from "@sendgrid/mail";

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, message: "Method not allowed" });
  }

  const { email } = req.body;
  const otp = Math.floor(1000 + Math.random() * 9000).toString();

  try {
    await sgMail.send({
      to: email,
      from: "abaqkingdom@gmail.com", // ✅ بريدك الموثق
      subject: "رمز التحقق من ABAQ Kingdom",
      text: `رمز التحقق الخاص بك هو: ${otp}`,
      html: `<p>رمز التحقق الخاص بك هو: <strong>${otp}</strong></p>`,
    });

    res.status(200).json({ success: true, otp }); // ⚠️ لأغراض الاختبار فقط
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "فشل في إرسال البريد" });
  }
}
