
export default function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, message: "Method not allowed" });
  }

  const { email, otp } = req.body;

  // ⚠️ محاكاة التحقق فقط - لا تحفظ أكواد حقيقية هنا
  if (otp === "1234") {
    return res.status(200).json({ success: true });
  }

  res.status(400).json({ success: false, message: "رمز غير صحيح" });
}
