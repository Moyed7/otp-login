
const sgMail = require("@sendgrid/mail");
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { email } = req.body;
  const otp = Math.floor(1000 + Math.random() * 9000).toString();

  const msg = {
    to: email,
    from: "your_verified_sender@example.com", // غيّر هذا إلى بريدك الموثق في SendGrid
    subject: "رمز التحقق للدخول",
    text: `رمز الدخول الخاص بك هو: ${otp}`,
    html: `<strong>رمز الدخول الخاص بك هو: ${otp}</strong>`,
  };

  try {
    await sgMail.send(msg);
    res.status(200).json({ success: true, otp });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false });
  }
}
